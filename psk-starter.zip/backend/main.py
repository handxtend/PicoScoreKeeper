from fastapi import FastAPI
app=FastAPI(title='PSK Starter API')
@app.get('/health')
def h(): return {'ok':True}
